import React from 'react'
import Home from './Components/User/Home'
import About from './Components/User/About'
import User_Header from './Components/User/User_Header'
import User_Footer from './Components/User/User_Footer'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import User_Layout from './Layout/User_L/User_Layout'
import Contact from './Components/User/Contact'


const App = () => {

  return (

    <>
      <BrowserRouter>
    <Routes>
      <Route path='/' element={<User_Layout/>}>
        <Route path='/' element={<Home/>}></Route>
        <Route path='/contact' element={<Contact/>}></Route>
        <Route path='/about' element={<About/>}></Route>
      </Route>
    </Routes>
  </BrowserRouter>

      {/* <h1>Hlo</h1> */}

    </>

  )

}

export default App
