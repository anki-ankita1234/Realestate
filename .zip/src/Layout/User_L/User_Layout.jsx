import React from 'react'
import User_Header from '../../Components/User/User_Header'
import { Outlet } from 'react-router-dom'
import User_Footer from '../../Components/User/User_Footer'

const User_Layout = () => {
  return (
    <>
    <User_Header/>
    <Outlet/>
    <User_Footer/>
    </>
  )
}

export default User_Layout
